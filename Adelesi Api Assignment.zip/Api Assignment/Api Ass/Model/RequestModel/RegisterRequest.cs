﻿namespace Api_Ass.Model.RequestModel
{
    public class RegisterRequest
    {
        public string? Name { get; set; }
        public string? Email { get; set; }
        //public string? Role = "Customer";
        public string? Password { get; set; }
    }
}   
