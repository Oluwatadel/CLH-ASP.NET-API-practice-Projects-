﻿namespace Api_Ass.Model.RequestModel
{
    public class UpdateRequestModel
    {
        public string? Name { get; set; }
        public string? Email { get; set; }
        public string? Password;
    }
}
